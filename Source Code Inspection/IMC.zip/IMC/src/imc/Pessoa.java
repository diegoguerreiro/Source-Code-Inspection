public class Pessoa 
{
 // atributos da classe
 
 String nome;
 float peso;
 float altura;
 
 // métodos da classe
 
 float calcularIMC()
 {
 //return peso/(altura*altura);
 return (float) (peso/Math.pow(altura, 2));
 }
 
 String classificarIMC()
 {
 float imc;
 String classe;
 imc = calcularIMC();
 
 if (imc < 19)
 classe = "Risco Baixo";
 else
 if (imc < 25)
 classe = "Ideal";
 else
 if (imc < 27.8)
 classe = "Risco Moderado";
 else
 classe = "Risco elevado";
 
 return classe;
 }
 

}