import java.util.Scanner;

public class IMC 
{
 public static void main(String a[])
 {
 Scanner ler = new Scanner(System.in);

 Pessoa p1;
 p1 = new Pessoa();
 
 System.out.println("Nome da Pessoa 1: ");
 p1.nome = ler.nextLine();
 System.out.println("Peso da Pessoa 1 (kg): ");
 p1.peso = ler.nextFloat();
 System.out.println("Altura da Pessoa 1 (m): ");
 p1.altura = ler.nextFloat();
 ler.nextLine();

 
 System.out.printf("IMC da Pessoa 1 = %.1f - %s\n", 
 p1.calcularIMC(), p1.classificarIMC()); 



 }
}
